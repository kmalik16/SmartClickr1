var config = {
	Server: 'http://smartclickr.com:8000'
}
