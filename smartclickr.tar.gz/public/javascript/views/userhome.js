$(document).ready(function() {
	if (data = true) {
		
	} 

}