module.exports = {
	host: 'smtp.gmail.com',
	sender: 'admin@smartclickr.com',
	password: 'Mcb_1991!sma',
	ssl: true
};