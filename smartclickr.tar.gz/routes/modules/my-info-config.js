module.exports = {
	user: 'smartclickr',
	pass: 'Morph1_sc!',
	host: 'mysql.morphatic.com',
	db:   'smartclickr'
}